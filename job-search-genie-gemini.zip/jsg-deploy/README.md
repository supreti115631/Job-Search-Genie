# 🧞 Job Search Genie — Gemini Edition (100% Free)

**Get Hired Smarter & Faster with AI.** A lightweight, mobile-first web app
powered by **Google Gemini 2.5 Flash** — permanently free, no credit card,
no expiry. Runs on the Gemini API free tier:

> 1,500 requests / day · 15 req/min · No credit card · No expiry

---

## What's in the box

```
job-search-genie/
├─ api/gemini.js        ← Serverless proxy (keeps your key off the client)
├─ src/
│  ├─ App.jsx           ← Full app — UI + logic
│  ├─ main.jsx          ← React entry point
│  └─ index.css         ← Base reset
├─ index.html
├─ vite.config.js
├─ vercel.json
├─ package.json
├─ .env.example         ← Copy → .env and add your key
└─ .gitignore
```

The browser **never sees your API key**. It calls `/api/gemini`, the
serverless function adds the key and translates the request into Gemini's
native format, then returns a response the app already understands.

---

## Step 1 — Get a free Gemini API key (2 minutes, no card)

1. Open **https://aistudio.google.com/apikey** in any browser.
2. Sign in with your Google account.
3. Click **"Create API Key"** → choose "Create API key in new project".
4. Copy the `AIzaSy…` string. That's your key.

**Free tier limits (as of 2026):**
| Model | Req / day | Req / min |
|---|---|---|
| Gemini 2.5 Flash | 1,500 | 15 |
| Gemini 2.5 Flash-Lite | 1,500 | 30 |

One full toolkit run ≈ 12 requests. One interview session ≈ 2 requests.
So the free tier comfortably supports dozens of users per day.

---

## Step 2 — Run locally (optional)

```bash
npm install
cp .env.example .env      # paste your AIzaSy… key in .env
npx vercel dev            # starts UI + /api/gemini function together
```

> `npm run dev` alone serves only the Vite UI — the `/api/gemini` function
> needs `vercel dev` (or a real deployment) to work.

Open the URL printed in your terminal.

---

## Step 3 — Deploy for free on Vercel (5 minutes)

Vercel's **Hobby** plan is permanently free and handles this app easily.

### Option A — GitHub import (easiest, no terminal)

1. Push this folder to a **new GitHub repo** (public or private).
2. Go to **https://vercel.com** → **Add New → Project** → import your repo.
3. Framework auto-detects as **Vite**. Leave all build settings as-is.
4. Before clicking Deploy, open **Environment Variables** and add:
   - **Name:** `GEMINI_API_KEY`
   - **Value:** `AIzaSy…` (your key)
5. Click **Deploy**.

Your app is live at `https://your-project.vercel.app` in ~60 seconds. ✅

### Option B — Vercel CLI

```bash
npm i -g vercel
vercel                              # link / create project
vercel env add GEMINI_API_KEY       # paste key when prompted → Production
vercel --prod                       # deploy
```

---

## Other free hosting options

### Netlify

1. Rename `api/gemini.js` → `netlify/functions/gemini.js`
2. Change the export to Netlify's handler format:

```js
export const handler = async (event) => {
  // replace  req.body  →  event.body
  // replace  res.status(200).json(data)  →  return { statusCode: 200, body: JSON.stringify(data) }
};
```

3. Add to `netlify.toml`:
```toml
[build]
  command = "npm run build"
  publish = "dist"

[[redirects]]
  from   = "/api/gemini"
  to     = "/.netlify/functions/gemini"
  status = 200
```

4. Add `GEMINI_API_KEY` in **Netlify → Site settings → Environment variables**.

### Cloudflare Pages

1. Create a Pages project (build: `npm run build`, output: `dist`).
2. Add a Pages Function at `functions/api/gemini.js` using Cloudflare's
   `export const onRequestPost = async (context) => { … }` format.
   Read the key from `context.env.GEMINI_API_KEY`.
3. Add `GEMINI_API_KEY` under **Settings → Environment variables**.

---

## Customisation

| Thing to change | Where |
|---|---|
| Model (e.g. Flash-Lite for speed) | `api/gemini.js` → `MODEL` constant |
| Max output tokens | `callClaude()` in `src/App.jsx` → `maxTokens` param |
| Contact email | `src/App.jsx` → `CONTACT_EMAIL` constant |
| App name / colours | `src/App.jsx` → top of file |

---

## Security checklist before going public

- ✅ Key lives only in host env vars, never in the repo
- ✅ `.env` is git-ignored
- ⬜ Add a `Referer` / `Origin` check in `api/gemini.js` so only your
  domain can call the proxy
- ⬜ Add rate limiting (e.g. Upstash Redis + Vercel Edge Middleware)
  if you expect high public traffic

---

## Costs

**$0.00** — as long as you stay under 1,500 requests/day on Gemini's free
tier. No credit card is ever required. If you outgrow the free tier,
Gemini 2.5 Flash pay-as-you-go is one of the cheapest options available
($0.15 / $0.60 per million tokens at the time of writing).

Happy job hunting. 🧞✨
