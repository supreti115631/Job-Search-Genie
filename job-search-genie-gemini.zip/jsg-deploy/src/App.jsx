import React, { useState, useEffect, useRef, useMemo } from "react";
import mammoth from "mammoth";
import {
  Sparkles, FileText, Mic, Home as HomeIco, Upload, Copy, Mail, LifeBuoy,
  Users, Plus, Check, ChevronRight, ChevronDown, RefreshCw, Trash2, ArrowRight,
  Wand2, FileDown, X, Lightbulb, Star, ListChecks, Target, MessageSquareQuote,
  Briefcase, BadgeCheck, FileType, Award,
} from "lucide-react";

/* localStorage-backed persistence (replaces the in-artifact storage API) */
const store = {
  async get(k) { const v = localStorage.getItem(k); return v == null ? null : { value: v }; },
  async set(k, v) { try { localStorage.setItem(k, v); } catch (e) {} },
  async delete(k) { try { localStorage.removeItem(k); } catch (e) {} },
};

/* ============================================================
   JOB SEARCH GENIE — live prototype (v2)
   + multi-profile switcher  + PDF/Word export  + richer motion
   ============================================================ */

const C = {
  ink: "#0E0A1F", ink2: "#161033", panel: "#1B1442",
  border: "rgba(167,139,250,0.22)", borderGold: "rgba(245,194,75,0.45)",
  gold: "#F5C24B", goldDeep: "#E8A317", amethyst: "#A78BFA", amethystDeep: "#7C5CF0",
  teal: "#34D3B0", coral: "#FF8A66", text: "#F5F2FF", mid: "#BCB2DD", dim: "#8A82AE",
};

const SECTIONS = [
  { id: "cover", title: "ATS Cover Letter", Icon: FileText, brief: "an ATS-friendly cover letter of 350-450 words, addressed to the hiring manager, tailored to the job description, professional and results-oriented. Plain text only." },
  { id: "recruiter", title: "Recruiter Outreach Email", Icon: Mail, brief: "a recruiter outreach email with a 'Subject:' line and a concise, confident body that highlights fit." },
  { id: "hm", title: "Hiring Manager Email", Icon: Mail, brief: "a hiring manager email with a 'Subject:' line and a short, persuasive body making the case for an interview." },
  { id: "linkedin", title: "LinkedIn Connection Note", Icon: Users, brief: "a LinkedIn connection request message, maximum 300 characters, warm and specific. End with the exact character count in parentheses." },
  { id: "referral", title: "Referral Request", Icon: MessageSquareQuote, brief: "a warm referral request message to a contact at the target company, easy for them to act on." },
  { id: "followup", title: "Follow-Up Email", Icon: RefreshCw, brief: "a polite follow-up email to send 5 days after no response, with a 'Subject:' line and a brief body." },
  { id: "intro", title: "30-Second Intro", Icon: Mic, brief: "a 30-second spoken self-introduction of roughly 70-85 words, natural and confident, for interviews and networking." },
  { id: "titles", title: "Top 10 Job Titles", Icon: Briefcase, brief: "the top 10 job titles best suited to this profile as a numbered list, ordered by fit." },
  { id: "strengths", title: "Key Strengths", Icon: Star, brief: "6-8 key strengths recruiters will notice, as concise one-line bullets starting with '- '." },
  { id: "gaps", title: "Skill Gap Analysis", Icon: ListChecks, brief: "a skill gap analysis in three clearly labeled parts: 'Current strengths', 'Missing skills (vs the JD)', and 'Recommended learning roadmap' (prioritized, with rough timeframes). Be honest and specific." },
  { id: "brand", title: "Personal Brand Summary", Icon: BadgeCheck, brief: "a personal brand summary with three labeled parts: 'Unique value proposition', 'Positioning statement', and 'Recruiter headline'." },
  { id: "interview", title: "Interview Talking Points", Icon: Target, brief: "interview talking points in three labeled parts: 'Most impressive achievements', 'Key STAR stories to prepare', and 'Likely question areas'. Concise bullets." },
];

const SYS_TOOLKIT =
  "You are an expert technical recruiter, executive resume writer, and career coach. Use ONLY the candidate's resume and the provided job description. Be specific and quantify achievements only where the resume genuinely supports it — never fabricate metrics, employers, or dates. Write in a professional, modern, results-oriented voice and avoid generic filler. Output ready-to-use content with NO preamble, NO markdown headers (#), and NO code fences. Use plain text with simple line breaks; use '- ' for bullets where helpful.";

const CONTACT_EMAIL = "sandeepupreti274@gmail.com";

/* ---------------- helpers ---------------- */
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
const initials = (n) => (n || "?").trim().split(/\s+/).slice(0, 2).map((w) => w[0]?.toUpperCase()).join("");
const escapeHtml = (s) => (s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

async function callClaude(system, userText, maxTokens = 1000, content = null) {
  // Powered by Gemini 2.5 Flash via /api/gemini proxy (free tier — no credit card)
  // Proxy translates to Gemini format and returns Anthropic-shaped response.
  const res = await fetch("/api/gemini", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      system,
      max_tokens: maxTokens,
      messages: [{ role: "user", content: content || userText }],
    }),
  });
  if (!res.ok) throw new Error("API error " + res.status);
  const data = await res.json();
  return (data.content || []).filter((b) => b.type === "text").map((b) => b.text).join("\n").trim();
}

function safeJSON(text) {
  if (!text) return null;
  let t = text.replace(/```json|```/g, "").trim();
  const a = t.indexOf("["), b = t.lastIndexOf("]"), c = t.indexOf("{"), d = t.lastIndexOf("}");
  let slice = t;
  if (a !== -1 && b !== -1 && (c === -1 || a < c)) slice = t.slice(a, b + 1);
  else if (c !== -1 && d !== -1) slice = t.slice(c, d + 1);
  try { return JSON.parse(slice); } catch (e) { return null; }
}

function fileToBase64(file) {
  return new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result).split(",")[1]); r.onerror = rej; r.readAsDataURL(file); });
}
async function fileToText(file) {
  const name = (file.name || "").toLowerCase();
  if (name.endsWith(".docx")) { const ab = await file.arrayBuffer(); return (await mammoth.extractRawText({ arrayBuffer: ab })).value; }
  if (name.endsWith(".pdf")) {
    const b64 = await fileToBase64(file);
    return await callClaude("You extract clean plain text from documents.", "", 4000, [
      { type: "document", source: { type: "base64", media_type: "application/pdf", data: b64 } },
      { type: "text", text: "Extract all readable text from this document. Output only the plain text, no commentary." },
    ]);
  }
  return await file.text();
}

function downloadBlob(filename, blob) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a"); a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
}

let jspdfPromise = null;
function loadJsPDF() {
  if (window.jspdf) return Promise.resolve(window.jspdf);
  if (jspdfPromise) return jspdfPromise;
  jspdfPromise = new Promise((res, rej) => {
    const s = document.createElement("script");
    s.src = "https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js";
    s.onload = () => res(window.jspdf); s.onerror = () => rej(new Error("pdf-load"));
    document.body.appendChild(s);
  });
  return jspdfPromise;
}

async function exportPDF(chosen, profile) {
  const { jsPDF } = await loadJsPDF();
  const doc = new jsPDF({ unit: "pt", format: "a4" });
  const pw = doc.internal.pageSize.getWidth(), ph = doc.internal.pageSize.getHeight();
  const M = 48, maxw = pw - M * 2;
  doc.setFillColor(17, 11, 40); doc.rect(0, 0, pw, 84, "F");
  doc.setTextColor(245, 194, 75); doc.setFont("helvetica", "bold"); doc.setFontSize(20);
  doc.text("Job Search Toolkit", M, 44);
  doc.setTextColor(188, 178, 221); doc.setFont("helvetica", "normal"); doc.setFontSize(10.5);
  doc.text(`${profile.name}  ·  ${profile.targetRole || "—"}${profile.targetCompany ? "  @ " + profile.targetCompany : ""}`, M, 62);
  doc.setTextColor(150, 140, 180); doc.setFontSize(8.5);
  doc.text("Generated by Job Search Genie", M, 76);
  let y = 112;
  chosen.forEach((s) => {
    if (y > ph - 96) { doc.addPage(); y = M; }
    doc.setFont("helvetica", "bold"); doc.setFontSize(13); doc.setTextColor(40, 30, 90);
    doc.text(s.title, M, y); y += 7;
    doc.setDrawColor(232, 163, 23); doc.setLineWidth(1.6); doc.line(M, y, M + 44, y); y += 17;
    doc.setFont("helvetica", "normal"); doc.setFontSize(10.5); doc.setTextColor(45, 45, 60);
    doc.splitTextToSize(s.content || "", maxw).forEach((line) => {
      if (y > ph - M) { doc.addPage(); y = M; }
      doc.text(line, M, y); y += 14.5;
    });
    y += 20;
  });
  const pages = doc.internal.getNumberOfPages();
  for (let i = 1; i <= pages; i++) { doc.setPage(i); doc.setFontSize(8); doc.setTextColor(150, 150, 170); doc.text(`${i} / ${pages}`, pw - M, ph - 18, { align: "right" }); }
  doc.save(`JobSearchGenie_${profile.name.replace(/\s+/g, "_")}.pdf`);
}

function exportWord(chosen, profile) {
  const body = chosen.map((s) =>
    `<h2 style="color:#7C5CF0;font-family:Calibri,Arial;margin:20px 0 4px;border-bottom:2px solid #F5C24B;padding-bottom:3px">${escapeHtml(s.title)}</h2>` +
    `<div style="font-family:Calibri,Arial;font-size:11pt;line-height:1.5;white-space:pre-wrap">${escapeHtml(s.content).replace(/\n/g, "<br>")}</div>`
  ).join("");
  const html = `<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'><head><meta charset='utf-8'><title>Job Search Toolkit</title></head><body>` +
    `<h1 style="font-family:Calibri;color:#241701;background:#F5C24B;padding:10px 12px;margin:0">Job Search Toolkit — ${escapeHtml(profile.name)}</h1>` +
    `<p style="font-family:Calibri;color:#555;margin:6px 0 4px">Target: ${escapeHtml(profile.targetRole || "—")}${profile.targetCompany ? " @ " + escapeHtml(profile.targetCompany) : ""} · Generated by Job Search Genie</p>` +
    body + `</body></html>`;
  downloadBlob(`JobSearchGenie_${profile.name.replace(/\s+/g, "_")}.doc`, new Blob(["\ufeff", html], { type: "application/msword" }));
}

/* ---------------- lamp logo ---------------- */
function Lamp({ size = 40, glow = true }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" fill="none" aria-hidden>
      <defs>
        <linearGradient id="goldg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#FCE9A8" /><stop offset="0.5" stopColor={C.gold} /><stop offset="1" stopColor={C.goldDeep} /></linearGradient>
        <radialGradient id="lglow" cx="0.5" cy="0.5" r="0.5"><stop offset="0" stopColor={C.gold} stopOpacity="0.55" /><stop offset="1" stopColor={C.gold} stopOpacity="0" /></radialGradient>
      </defs>
      {glow && <ellipse cx="34" cy="40" rx="28" ry="18" fill="url(#lglow)" />}
      <path d="M11 20 l1.6 4.2 4.2 1.6 -4.2 1.6 -1.6 4.2 -1.6 -4.2 -4.2 -1.6 4.2 -1.6 z" fill="#FCE9A8" className="jsg-twinkle2" />
      <path d="M14 40 C14 31 24 28 34 28 C47 28 56 32 56 39 C56 45 46 48 34 48 C24 48 14 47 14 40 Z" fill="url(#goldg)" />
      <path d="M14 39 L3 34 L3 31 L16 35 Z" fill="url(#goldg)" />
      <path d="M51 33 C60 31 60 45 51 44" stroke="url(#goldg)" strokeWidth="3.4" fill="none" strokeLinecap="round" />
      <path d="M28 28 Q34 22 41 28" stroke="url(#goldg)" strokeWidth="3" fill="none" strokeLinecap="round" />
      <circle cx="34.5" cy="22.5" r="3" fill="url(#goldg)" />
      <ellipse cx="33" cy="34" rx="9" ry="2.4" fill="#FFF4D2" opacity="0.6" />
    </svg>
  );
}

/* ---------------- atoms ---------------- */
const card = { background: "linear-gradient(160deg, rgba(40,28,92,0.55), rgba(22,16,51,0.65))", border: `1px solid ${C.border}`, borderRadius: 18, padding: 16, backdropFilter: "blur(6px)" };
const labelStyle = { fontFamily: "'Plus Jakarta Sans',system-ui", fontSize: 11, fontWeight: 700, letterSpacing: 1.2, textTransform: "uppercase", color: C.amethyst };

function Field({ label, value, onChange, placeholder, optional }) {
  return (
    <div style={{ marginBottom: 14 }}>
      <div style={{ ...labelStyle, marginBottom: 6 }}>{label} {optional && <span style={{ color: C.dim, fontWeight: 500, textTransform: "none", letterSpacing: 0 }}>· optional</span>}</div>
      <input value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} className="jsg-input" />
    </div>
  );
}

function Btn({ children, onClick, kind = "gold", disabled, full, small, shimmer }) {
  const styles = {
    gold: { background: `linear-gradient(135deg, ${C.gold}, ${C.goldDeep})`, color: "#241701", boxShadow: "0 8px 24px rgba(232,163,23,0.35)" },
    ghost: { background: "transparent", color: C.text, border: `1px solid ${C.border}` },
    violet: { background: `linear-gradient(135deg, ${C.amethyst}, ${C.amethystDeep})`, color: "#fff", boxShadow: "0 8px 24px rgba(124,92,240,0.35)" },
  }[kind];
  return (
    <button onClick={onClick} disabled={disabled} className={"jsg-btn" + (shimmer ? " jsg-shimmer" : "")}
      style={{ ...styles, width: full ? "100%" : "auto", padding: small ? "9px 14px" : "13px 18px", fontSize: small ? 13 : 15, opacity: disabled ? 0.45 : 1, cursor: disabled ? "not-allowed" : "pointer", display: "inline-flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
      {children}
    </button>
  );
}
const Avatar = ({ name, size = 42, active }) => (
  <div style={{ width: size, height: size, borderRadius: 14, flex: "none", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "'Fraunces',serif", fontWeight: 600, fontSize: size * 0.36, color: active ? "#241701" : "#fff", background: active ? `linear-gradient(135deg,${C.gold},${C.goldDeep})` : `linear-gradient(135deg,${C.amethyst},${C.amethystDeep})`, boxShadow: active ? "0 4px 14px rgba(232,163,23,0.4)" : "none" }}>{initials(name)}</div>
);

/* ============================================================ */
export default function App() {
  const [booted, setBooted] = useState(false);
  const [profiles, setProfiles] = useState([]);
  const [activeId, setActiveId] = useState(null);
  const [adding, setAdding] = useState(false);
  const [tab, setTab] = useState("home");
  const [toast, setToast] = useState(null);
  const [sections, setSections] = useState([]);

  const showToast = (msg) => { setToast(msg); setTimeout(() => setToast(null), 2200); };
  const active = profiles.find((p) => p.id === activeId) || null;

  useEffect(() => {
    (async () => {
      try { const p = await store.get("jsg:profiles"); if (p) setProfiles(JSON.parse(p.value)); } catch (e) {}
      try { const a = await store.get("jsg:activeId"); if (a) setActiveId(JSON.parse(a.value)); } catch (e) {}
      setBooted(true);
    })();
  }, []);

  // load toolkit for active profile
  useEffect(() => {
    if (!activeId) { setSections([]); return; }
    (async () => { try { const t = await store.get("jsg:toolkit:" + activeId); setSections(t ? JSON.parse(t.value) : []); } catch (e) { setSections([]); } })();
  }, [activeId]);

  const persistProfiles = async (list, act) => {
    setProfiles(list); try { await store.set("jsg:profiles", JSON.stringify(list)); } catch (e) {}
    if (act !== undefined) { setActiveId(act); try { await store.set("jsg:activeId", JSON.stringify(act)); } catch (e) {} }
  };
  const switchTo = async (id) => { setActiveId(id); try { await store.set("jsg:activeId", JSON.stringify(id)); } catch (e) {} setTab("home"); };
  const saveToolkit = (secs) => { setSections(secs); try { store.set("jsg:toolkit:" + activeId, JSON.stringify(secs)); } catch (e) {} };
  const addProfile = (p) => { const np = { ...p, id: uid() }; persistProfiles([...profiles, np], np.id); setAdding(false); setTab("home"); };
  const deleteProfile = (id) => {
    const left = profiles.filter((p) => p.id !== id);
    try { store.delete("jsg:toolkit:" + id); } catch (e) {}
    persistProfiles(left, id === activeId ? (left[0]?.id ?? null) : activeId);
  };

  const stars = useMemo(() => Array.from({ length: 46 }).map(() => ({ left: Math.random() * 100, top: Math.random() * 100, s: Math.random() * 1.8 + 0.6, d: Math.random() * 4 + 2, delay: Math.random() * 4 })), []);

  if (!booted) {
    return (<div style={shell.bg}><GlobalStyle /><div style={{ ...shell.frame, display: "flex", alignItems: "center", justifyContent: "center" }}>
      <div style={{ textAlign: "center" }}><div className="jsg-float"><Lamp size={64} /></div><div style={{ color: C.mid, marginTop: 14, fontFamily: "'Plus Jakarta Sans'", fontSize: 14 }}>Warming up the lamp…</div></div>
    </div></div>);
  }

  const needsOnboarding = profiles.length === 0 || adding;

  return (
    <div style={shell.bg}>
      <GlobalStyle />
      <div style={shell.frame}>
        <div style={{ position: "absolute", inset: 0, overflow: "hidden", pointerEvents: "none" }}>
          {stars.map((st, i) => (<div key={i} className="jsg-star" style={{ left: st.left + "%", top: st.top + "%", width: st.s, height: st.s, animationDuration: st.d + "s", animationDelay: st.delay + "s" }} />))}
          <div style={shell.aura} className="jsg-aura" />
        </div>

        {needsOnboarding ? (
          <Onboarding onDone={addProfile} onCancel={profiles.length ? () => setAdding(false) : null} count={profiles.length} />
        ) : (
          <>
            <TopBar tab={tab} profile={active} onAvatar={() => setTab("home")} />
            <div style={shell.scroll}>
              {tab === "home" && <Home key={"home" + activeId} profile={active} profiles={profiles} activeId={activeId} go={setTab} onSwitch={switchTo} onAdd={() => setAdding(true)} onDelete={deleteProfile} />}
              {tab === "toolkit" && <Toolkit key={"tk" + activeId} profile={active} sections={sections} setSections={saveToolkit} showToast={showToast} />}
              {tab === "interview" && <Interview key={"iv" + activeId} profile={active} showToast={showToast} />}
            </div>
            <TabBar tab={tab} setTab={setTab} />
          </>
        )}
        {toast && <div style={shell.toast} className="jsg-pop"><Sparkles size={14} color={C.gold} /> {toast}</div>}
      </div>
    </div>
  );
}

/* ---------------- Onboarding ---------------- */
function Onboarding({ onDone, onCancel, count }) {
  const [step, setStep] = useState(onCancel ? 1 : 0);
  const [f, setF] = useState({ name: "", currentRole: "", company: "", targetRole: "", targetCompany: "" });
  const set = (k) => (v) => setF((p) => ({ ...p, [k]: v }));
  const canFinish = f.name.trim() && f.currentRole.trim();
  return (
    <div style={{ ...shell.scroll, padding: "8px 20px 28px", position: "relative", zIndex: 2 }} className="jsg-screen">
      {step === 0 ? (
        <div style={{ paddingTop: 46, textAlign: "center" }}>
          <div className="jsg-float" style={{ display: "inline-block" }}><Lamp size={84} /></div>
          <h1 style={{ fontFamily: "'Fraunces',Georgia,serif", fontSize: 34, color: C.text, margin: "18px 0 6px", fontWeight: 600, lineHeight: 1.1 }}>Job Search<br /><span style={{ color: C.gold }}>Genie</span></h1>
          <p style={{ fontFamily: "'Plus Jakarta Sans'", color: C.mid, fontSize: 15, margin: "0 auto 26px", maxWidth: 300, lineHeight: 1.5 }}>Get hired smarter & faster with AI. Three wishes: a tailored toolkit, sharper positioning, and interview confidence.</p>
          <Btn full kind="gold" shimmer onClick={() => setStep(1)}><Sparkles size={17} /> Rub the lamp to begin</Btn>
        </div>
      ) : (
        <div style={{ paddingTop: 14 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div style={labelStyle}>{onCancel ? "Add account" : "Step 1 of 1"}</div>
            {onCancel && <button className="jsg-x" onClick={onCancel}><X size={18} /></button>}
          </div>
          <h2 style={{ fontFamily: "'Fraunces',serif", fontSize: 24, color: C.text, margin: "4px 0 4px", fontWeight: 600 }}>{onCancel ? "New profile" : "Tell the Genie about you"}</h2>
          <p style={{ fontFamily: "'Plus Jakarta Sans'", color: C.dim, fontSize: 13, margin: "0 0 20px" }}>Personalizes every email, letter, and interview. Saved on this device.</p>
          <div style={card}>
            <Field label="Your name" value={f.name} onChange={set("name")} placeholder="e.g. Sandeep Upreti" />
            <Field label="Current role" value={f.currentRole} onChange={set("currentRole")} placeholder="e.g. Data Solution Architect" />
            <Field label="Current company" value={f.company} onChange={set("company")} placeholder="e.g. EXL Service" />
            <Field label="Target role" value={f.targetRole} onChange={set("targetRole")} placeholder="e.g. Azure Data Engineer" optional />
            <Field label="Target company" value={f.targetCompany} onChange={set("targetCompany")} placeholder="e.g. Alian Technologies" optional />
          </div>
          <div style={{ marginTop: 18 }}><Btn full kind="gold" shimmer disabled={!canFinish} onClick={() => onDone(f)}>{canFinish ? (<>Enter Job Search Genie <ArrowRight size={17} /></>) : "Add your name & current role"}</Btn></div>
        </div>
      )}
    </div>
  );
}

/* ---------------- Top bar ---------------- */
function TopBar({ tab, profile, onAvatar }) {
  const titles = { home: "Job Search Genie", toolkit: "Toolkit Generator", interview: "Live Interview" };
  return (
    <div style={shell.top}>
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <Lamp size={30} glow={false} />
        <div>
          <div style={{ fontFamily: "'Fraunces',serif", fontWeight: 600, fontSize: 16, color: C.text, lineHeight: 1 }}>{titles[tab]}</div>
          <div style={{ fontFamily: "'Plus Jakarta Sans'", fontSize: 11, color: C.dim, marginTop: 2 }}>Hi {profile.name.split(" ")[0]} · {profile.targetRole || profile.currentRole}</div>
        </div>
      </div>
      <button onClick={onAvatar} style={{ background: "none", border: "none", cursor: "pointer", padding: 0 }}><Avatar name={profile.name} size={34} /></button>
    </div>
  );
}

/* ---------------- Profile switcher ---------------- */
function ProfileSwitcher({ profiles, activeId, onSwitch, onAdd, onDelete }) {
  const [open, setOpen] = useState(false);
  const me = profiles.find((p) => p.id === activeId);
  return (
    <div style={{ ...card, padding: 14, marginBottom: 16, borderColor: C.borderGold }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
        <Avatar name={me.name} active />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontFamily: "'Fraunces',serif", fontWeight: 600, fontSize: 16, color: C.text, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{me.name}</div>
          <div style={{ fontFamily: "'Plus Jakarta Sans'", fontSize: 12, color: C.dim, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{me.currentRole}{me.company ? " · " + me.company : ""}</div>
        </div>
        <button className="jsg-chip" onClick={() => setOpen(!open)} style={{ display: "flex", alignItems: "center", gap: 4 }}>Switch <ChevronDown size={14} style={{ transform: open ? "rotate(180deg)" : "none", transition: ".2s" }} /></button>
      </div>

      {open && (
        <div className="jsg-expand" style={{ marginTop: 12, borderTop: `1px solid ${C.border}`, paddingTop: 10 }}>
          {profiles.filter((p) => p.id !== activeId).map((p, i) => (
            <div key={p.id} className="jsg-row" style={{ animationDelay: i * 50 + "ms" }}>
              <button onClick={() => { onSwitch(p.id); setOpen(false); }} style={{ display: "flex", alignItems: "center", gap: 10, flex: 1, background: "none", border: "none", cursor: "pointer", padding: "8px 0", minWidth: 0 }}>
                <Avatar name={p.name} size={34} />
                <div style={{ textAlign: "left", minWidth: 0 }}>
                  <div style={{ fontFamily: "'Plus Jakarta Sans'", fontWeight: 700, fontSize: 13.5, color: C.text, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{p.name}</div>
                  <div style={{ fontFamily: "'Plus Jakarta Sans'", fontSize: 11.5, color: C.dim, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{p.targetRole || p.currentRole}</div>
                </div>
              </button>
              <button className="jsg-x" onClick={() => onDelete(p.id)} title="Remove"><Trash2 size={16} /></button>
            </div>
          ))}
          {profiles.length === 1 && <div style={{ fontFamily: "'Plus Jakarta Sans'", fontSize: 12, color: C.dim, padding: "6px 0" }}>No other profiles yet.</div>}
          <button className="jsg-add" onClick={() => { onAdd(); setOpen(false); }}><Plus size={16} /> Add account</button>
        </div>
      )}
    </div>
  );
}

/* ---------------- Home ---------------- */
function Home({ profile, profiles, activeId, go, onSwitch, onAdd, onDelete }) {
  const steps = [
    { n: "1", t: "Switch or add a profile", d: "Run separate searches for different roles or people." },
    { n: "2", t: "Generate your toolkit", d: "Paste or upload a job description + resume to create 12 tailored assets." },
    { n: "3", t: "Practice live interview", d: "Pick a role and difficulty, then get a score and feedback." },
  ];
  const [panel, setPanel] = useState(null);
  return (
    <div style={{ padding: "14px 18px 30px", position: "relative", zIndex: 2 }} className="jsg-screen">
      <ProfileSwitcher profiles={profiles} activeId={activeId} onSwitch={onSwitch} onAdd={onAdd} onDelete={onDelete} />

      <div style={{ ...card, padding: 22, textAlign: "center", borderColor: C.borderGold, background: "linear-gradient(160deg, rgba(245,194,75,0.12), rgba(124,92,240,0.10))" }} className="jsg-reveal">
        <div className="jsg-float" style={{ display: "inline-block" }}><Lamp size={62} /></div>
        <h2 style={{ fontFamily: "'Fraunces',serif", fontSize: 23, color: C.text, margin: "12px 0 6px", fontWeight: 600, lineHeight: 1.15 }}>Get Hired Smarter<br />& Faster with AI!</h2>
        <p style={{ fontFamily: "'Plus Jakarta Sans'", color: C.mid, fontSize: 13.5, margin: 0, lineHeight: 1.5 }}>Your personal genie for job-search wins — tailored applications and interview-ready confidence in minutes.</p>
        <div style={{ display: "flex", gap: 10, marginTop: 18 }}>
          <Btn full kind="gold" onClick={() => go("toolkit")}><Wand2 size={16} /> Toolkit</Btn>
          <Btn full kind="violet" onClick={() => go("interview")}><Mic size={16} /> Interview</Btn>
        </div>
      </div>

      <div style={{ ...labelStyle, margin: "24px 0 10px" }}>How it works</div>
      {steps.map((s, i) => (
        <div key={s.n} style={{ ...card, display: "flex", gap: 14, alignItems: "flex-start", marginBottom: 10, padding: 14, animationDelay: 80 + i * 70 + "ms" }} className="jsg-reveal">
          <div className="jsg-num">{s.n}</div>
          <div><div style={{ fontFamily: "'Plus Jakarta Sans'", fontWeight: 700, color: C.text, fontSize: 14.5 }}>{s.t}</div>
            <div style={{ fontFamily: "'Plus Jakarta Sans'", color: C.dim, fontSize: 12.5, marginTop: 2, lineHeight: 1.45 }}>{s.d}</div></div>
        </div>
      ))}

      <div style={{ display: "flex", gap: 10, marginTop: 16 }}>
        <button className="jsg-tile" onClick={() => setPanel(panel === "contact" ? null : "contact")}><Mail size={20} color={C.gold} /><span>Contact us</span></button>
        <button className="jsg-tile" onClick={() => setPanel(panel === "support" ? null : "support")}><LifeBuoy size={20} color={C.amethyst} /><span>Support</span></button>
      </div>

      {panel === "contact" && (
        <div style={{ ...card, marginTop: 12 }} className="jsg-pop">
          <div style={{ ...labelStyle, marginBottom: 8 }}>Contact us</div>
          <p style={{ fontFamily: "'Plus Jakarta Sans'", color: C.mid, fontSize: 13.5, margin: "0 0 10px", lineHeight: 1.5 }}>Questions, feedback, or ideas? Reach out directly:</p>
          <a href={"mailto:" + CONTACT_EMAIL} className="jsg-mail"><Mail size={16} /> {CONTACT_EMAIL}</a>
        </div>
      )}
      {panel === "support" && (
        <div style={{ ...card, marginTop: 12 }} className="jsg-pop">
          <div style={{ ...labelStyle, marginBottom: 8 }}>Support & guidelines</div>
          {[["Best inputs", "Paste the full job description and your most recent resume for sharpest results."], ["Multiple profiles", "Use the switcher up top to keep separate searches for different roles or people."], ["Your data", "Profiles stay on this device. Files are used only to generate your toolkit."], ["Download", "Select sections in the Toolkit tab, then export as PDF or Word."]].map(([h, d]) => (
            <div key={h} style={{ marginBottom: 10 }}><div style={{ fontFamily: "'Plus Jakarta Sans'", fontWeight: 700, color: C.text, fontSize: 13.5 }}>{h}</div><div style={{ fontFamily: "'Plus Jakarta Sans'", color: C.dim, fontSize: 12.5, lineHeight: 1.45 }}>{d}</div></div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ---------------- Toolkit ---------------- */
function InputBlock({ title, hint, text, setText, file, setFile, accept }) {
  const ref = useRef();
  return (
    <div style={{ ...card, marginBottom: 14 }} className="jsg-reveal">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
        <div style={labelStyle}>{title}</div>
        <button className="jsg-chip" onClick={() => ref.current.click()} style={{ display: "flex", alignItems: "center", gap: 5 }}><Upload size={13} /> Upload</button>
        <input ref={ref} type="file" accept={accept} style={{ display: "none" }} onChange={(e) => { const fl = e.target.files[0]; if (fl) { setFile(fl); setText(""); } }} />
      </div>
      {file ? (
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", background: "rgba(124,92,240,0.14)", border: `1px solid ${C.border}`, borderRadius: 12, padding: "10px 12px" }}>
          <span style={{ display: "flex", alignItems: "center", gap: 8, fontFamily: "'Plus Jakarta Sans'", fontSize: 13, color: C.text, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}><FileType size={16} color={C.amethyst} /> {file.name}</span>
          <button className="jsg-x" onClick={() => setFile(null)}><X size={16} /></button>
        </div>
      ) : (<textarea className="jsg-area" value={text} onChange={(e) => setText(e.target.value)} placeholder={hint} />)}
    </div>
  );
}

function Toolkit({ profile, sections, setSections, showToast }) {
  const [jdText, setJdText] = useState(""); const [resumeText, setResumeText] = useState("");
  const [jdFile, setJdFile] = useState(null); const [resumeFile, setResumeFile] = useState(null);
  const [busy, setBusy] = useState(false); const [progress, setProgress] = useState(0); const [stage, setStage] = useState("");
  const [selected, setSelected] = useState({}); const [open, setOpen] = useState({});
  const [spark, setSpark] = useState(false); const [sheet, setSheet] = useState(false);

  const hasInput = (jdText.trim() || jdFile) && (resumeText.trim() || resumeFile);
  const ready = sections.length > 0;
  const selCount = Object.values(selected).filter(Boolean).length;

  const buildCtx = (jd, resume) => `CANDIDATE PROFILE\nName: ${profile.name}\nCurrent: ${profile.currentRole}${profile.company ? " at " + profile.company : ""}\nTarget role: ${profile.targetRole || "(open)"}\nTarget company: ${profile.targetCompany || "(open)"}\n\nJOB DESCRIPTION:\n${jd}\n\nRESUME:\n${resume}`;

  async function generate() {
    setBusy(true); setProgress(0); setStage("Reading your documents…");
    try {
      const jd = jdText.trim() || (jdFile ? await fileToText(jdFile) : "");
      const resume = resumeText.trim() || (resumeFile ? await fileToText(resumeFile) : "");
      if (!jd || !resume) { showToast("Add both a job description and resume"); setBusy(false); return; }
      const ctx = buildCtx(jd, resume);
      const fresh = SECTIONS.map((s) => ({ id: s.id, title: s.title, content: "", status: "queued" }));
      setSections(fresh); setStage("Granting your 12 wishes…");
      const results = [...fresh]; let done = 0; const idxs = [...SECTIONS.keys()];
      const worker = async () => {
        while (idxs.length) {
          const i = idxs.shift();
          results[i] = { ...results[i], status: "loading" }; setSections([...results]);
          try { results[i] = { ...results[i], content: await callClaude(SYS_TOOLKIT, `${ctx}\n\nGenerate ONLY ${SECTIONS[i].brief}`, 1000), status: "done" }; }
          catch (e) { results[i] = { ...results[i], status: "error", content: "" }; }
          done++; setProgress(Math.round((done / SECTIONS.length) * 100)); setSections([...results]);
        }
      };
      await Promise.all([worker(), worker(), worker()]);
      setStage(""); setSpark(true); setTimeout(() => setSpark(false), 1400); showToast("Toolkit ready");
    } catch (e) { showToast("Something went wrong — try again"); }
    finally { setBusy(false); }
  }

  function toggleSel(id) { setSelected((p) => ({ ...p, [id]: !p[id] })); }
  function selectAll() { const done = sections.filter((s) => s.status === "done"); const all = done.every((s) => selected[s.id]); const next = {}; done.forEach((s) => (next[s.id] = !all)); setSelected(next); }
  function chosenList() { return sections.filter((s) => selected[s.id] && s.content); }
  async function doExport(fmt) {
    const chosen = chosenList(); if (!chosen.length) { showToast("Select at least one section"); return; }
    setSheet(false);
    try {
      if (fmt === "pdf") { await exportPDF(chosen, profile); showToast("PDF downloaded"); }
      else { exportWord(chosen, profile); showToast("Word doc downloaded"); }
    } catch (e) { showToast(fmt === "pdf" ? "PDF engine blocked — try Word" : "Export failed"); }
  }

  const SECMAP = Object.fromEntries(SECTIONS.map((s) => [s.id, s.Icon]));

  return (
    <div style={{ padding: "14px 18px 30px", position: "relative", zIndex: 2 }} className="jsg-screen">
      {spark && <div style={{ position: "absolute", top: 40, left: 0, right: 0, height: 0, zIndex: 30, pointerEvents: "none" }}>
        {Array.from({ length: 12 }).map((_, i) => (<span key={i} className="jsg-spark" style={{ left: 50 + (Math.random() * 40 - 20) + "%", "--tx": (Math.random() * 180 - 90) + "px", "--ty": (Math.random() * 160 + 40) + "px", animationDelay: i * 30 + "ms", color: i % 2 ? C.gold : C.amethyst }}>✦</span>))}
      </div>}

      {!ready && !busy && <p style={{ fontFamily: "'Plus Jakarta Sans'", color: C.mid, fontSize: 13.5, margin: "0 0 14px", lineHeight: 1.5 }}>Paste or upload the job description and your resume. The Genie crafts 12 tailored, ready-to-send assets for <b style={{ color: C.text }}>{profile.name.split(" ")[0]}</b>.</p>}

      {(!ready || busy) && (<>
        <InputBlock title="Job description" hint="Paste the job description here…" text={jdText} setText={setJdText} file={jdFile} setFile={setJdFile} accept=".txt,.md,.pdf,.docx" />
        <InputBlock title="Your resume" hint="Paste your resume here…" text={resumeText} setText={setResumeText} file={resumeFile} setFile={setResumeFile} accept=".txt,.md,.pdf,.docx" />
      </>)}

      {busy ? (
        <div style={{ ...card, textAlign: "center", padding: 22 }}>
          <div className="jsg-float" style={{ display: "inline-block" }}><Lamp size={50} /></div>
          <div style={{ fontFamily: "'Plus Jakarta Sans'", color: C.text, fontWeight: 700, fontSize: 14, marginTop: 10 }}>{stage}</div>
          <div className="jsg-track"><div className="jsg-fill" style={{ width: progress + "%" }} /></div>
          <div style={{ fontFamily: "'Plus Jakarta Sans'", color: C.dim, fontSize: 12, marginTop: 8 }}>{progress}% · {sections.filter((s) => s.status === "done").length}/12 sections</div>
        </div>
      ) : !ready ? (
        <Btn full kind="gold" shimmer disabled={!hasInput} onClick={generate}>{hasInput ? (<><Sparkles size={17} /> Generate my toolkit</>) : "Add a job description & resume"}</Btn>
      ) : null}

      {ready && !busy && (<>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", margin: "4px 0 12px" }}>
          <button className="jsg-chip" onClick={selectAll}><Check size={13} /> Select all</button>
          <button className="jsg-chip" onClick={() => { setSections([]); setSelected({}); }}><RefreshCw size={13} /> New</button>
        </div>
        {sections.map((s, i) => { const Ico = SECMAP[s.id] || FileText; return (
          <div key={s.id} style={{ ...card, marginBottom: 10, padding: 0, overflow: "hidden", borderColor: selected[s.id] ? C.borderGold : C.border, animationDelay: i * 35 + "ms" }} className="jsg-reveal">
            <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "13px 14px" }}>
              <button className="jsg-check" data-on={!!selected[s.id]} onClick={() => s.status === "done" && toggleSel(s.id)} disabled={s.status !== "done"}>{selected[s.id] ? <Check size={14} /> : ""}</button>
              <Ico size={17} color={s.status === "done" ? C.gold : C.dim} style={{ flex: "none" }} />
              <div style={{ flex: 1, cursor: "pointer", minWidth: 0 }} onClick={() => setOpen((p) => ({ ...p, [s.id]: !p[s.id] }))}>
                <div style={{ fontFamily: "'Plus Jakarta Sans'", fontWeight: 700, color: C.text, fontSize: 14 }}>{s.title}</div>
                <div style={{ fontFamily: "'Plus Jakarta Sans'", fontSize: 11.5, color: s.status === "error" ? C.coral : C.dim, marginTop: 1 }}>{s.status === "loading" ? "Conjuring…" : s.status === "error" ? "Failed — tap New to retry" : s.status === "queued" ? "Queued" : "Ready · tap to preview"}</div>
              </div>
              {s.status === "done" && <button className="jsg-chip" onClick={() => { navigator.clipboard?.writeText(s.content); showToast("Copied"); }}><Copy size={13} /></button>}
            </div>
            {open[s.id] && s.content && (<div style={{ padding: "0 14px 14px" }}><div style={{ fontFamily: "'Plus Jakarta Sans'", whiteSpace: "pre-wrap", color: C.mid, fontSize: 13, lineHeight: 1.55, background: "rgba(14,10,31,0.5)", border: `1px solid ${C.border}`, borderRadius: 12, padding: 12 }}>{s.content}</div></div>)}
          </div>
        ); })}
        <div style={{ position: "sticky", bottom: 8, marginTop: 14 }}>
          <Btn full kind="gold" shimmer={selCount > 0} disabled={selCount === 0} onClick={() => setSheet(true)}><FileDown size={17} /> {selCount ? `Export report (${selCount})` : "Select sections to export"}</Btn>
        </div>
      </>)}

      {sheet && (
        <div style={shell.sheetWrap} onClick={() => setSheet(false)}>
          <div style={shell.sheet} className="jsg-slide" onClick={(e) => e.stopPropagation()}>
            <div style={{ width: 40, height: 4, borderRadius: 99, background: C.border, margin: "0 auto 14px" }} />
            <div style={{ ...labelStyle, marginBottom: 12, textAlign: "center" }}>Export {selCount} section{selCount > 1 ? "s" : ""}</div>
            <button className="jsg-export" onClick={() => doExport("pdf")}><span style={{ display: "flex", alignItems: "center", gap: 12 }}><span className="jsg-ei" style={{ background: "rgba(255,138,102,0.16)" }}><FileText size={20} color={C.coral} /></span><span><b>PDF document</b><small>Polished, print-ready, shareable</small></span></span><ChevronRight size={18} color={C.dim} /></button>
            <button className="jsg-export" onClick={() => doExport("word")}><span style={{ display: "flex", alignItems: "center", gap: 12 }}><span className="jsg-ei" style={{ background: "rgba(76,118,255,0.16)" }}><FileType size={20} color="#6E8BFF" /></span><span><b>Word document (.doc)</b><small>Editable in Microsoft Word</small></span></span><ChevronRight size={18} color={C.dim} /></button>
            <button className="jsg-chip" style={{ width: "100%", marginTop: 12, padding: 12, justifyContent: "center" }} onClick={() => setSheet(false)}>Cancel</button>
          </div>
        </div>
      )}
    </div>
  );
}

/* ---------------- Interview ---------------- */
function ScoreRing({ score }) {
  const [val, setVal] = useState(0);
  useEffect(() => { let raf; const t0 = performance.now(); const dur = 900; const tick = (t) => { const k = Math.min(1, (t - t0) / dur); setVal(Math.round(score * (1 - Math.pow(1 - k, 3)))); if (k < 1) raf = requestAnimationFrame(tick); }; raf = requestAnimationFrame(tick); return () => cancelAnimationFrame(raf); }, [score]);
  const r = 52, circ = 2 * Math.PI * r; const col = score >= 80 ? C.teal : score >= 60 ? C.gold : C.coral;
  return (
    <svg width="140" height="140" viewBox="0 0 140 140">
      <circle cx="70" cy="70" r={r} fill="none" stroke="rgba(167,139,250,0.18)" strokeWidth="11" />
      <circle cx="70" cy="70" r={r} fill="none" stroke={col} strokeWidth="11" strokeLinecap="round" strokeDasharray={circ} strokeDashoffset={circ * (1 - val / 100)} transform="rotate(-90 70 70)" />
      <text x="70" y="66" textAnchor="middle" fontFamily="'Fraunces',serif" fontSize="34" fontWeight="600" fill={C.text}>{val}</text>
      <text x="70" y="88" textAnchor="middle" fontFamily="'Plus Jakarta Sans'" fontSize="11" fill={C.dim} letterSpacing="1">/ 100</text>
    </svg>
  );
}

function Interview({ profile, showToast }) {
  const [phase, setPhase] = useState("setup");
  const [role, setRole] = useState(profile.targetRole || profile.currentRole || "");
  const [diff, setDiff] = useState("Medium");
  const [questions, setQuestions] = useState([]); const [qi, setQi] = useState(0);
  const [answer, setAnswer] = useState(""); const [log, setLog] = useState([]); const [result, setResult] = useState(null);
  const counts = { Easy: 6, Medium: 9, Hard: 12 };

  async function start() {
    if (!role.trim()) { showToast("Enter a target role"); return; }
    setPhase("loading"); const n = counts[diff];
    try {
      const out = await callClaude("You are a senior interviewer. Return ONLY a JSON array of interview question strings — no markdown, no numbering, no commentary.",
        `Create ${n} interview questions for a "${role}" role at "${diff}" difficulty. Mix behavioral and role-specific technical questions appropriate to the level. Tailor to this candidate background: ${profile.currentRole}${profile.company ? " at " + profile.company : ""}. Return a JSON array of ${n} concise question strings.`, 1000);
      let qs = safeJSON(out);
      if (!Array.isArray(qs) || !qs.length) qs = out.split("\n").map((l) => l.replace(/^[\d\-.\)\s]+/, "").trim()).filter(Boolean);
      setQuestions(qs.slice(0, 15)); setQi(0); setLog([]); setAnswer(""); setPhase("asking");
    } catch (e) { showToast("Couldn't start — try again"); setPhase("setup"); }
  }
  function submitAnswer(skip) {
    const newLog = [...log, { q: questions[qi], a: skip ? "(skipped)" : answer.trim() || "(no answer)" }];
    setLog(newLog); setAnswer("");
    if (qi + 1 < questions.length) setQi(qi + 1); else score(newLog);
  }
  async function score(finalLog) {
    setPhase("scoring");
    try {
      const transcript = finalLog.map((e, i) => `Q${i + 1}: ${e.q}\nA${i + 1}: ${e.a}`).join("\n\n");
      const out = await callClaude("You are a fair, encouraging interview coach. Return ONLY valid JSON, no markdown.",
        `Role: ${role}. Difficulty: ${diff}.\nTranscript:\n${transcript}\n\nEvaluate the candidate. Return JSON with keys: score (integer 0-100), band (one of "Needs work","Promising","Strong","Interview-ready"), summary (2-3 sentences, second person), strengths (array of 3 short strings), improvements (array of 3-4 short, actionable strings).`, 1000);
      setResult(safeJSON(out) || { score: 0, band: "—", summary: out.slice(0, 300), strengths: [], improvements: [] }); setPhase("result");
    } catch (e) { showToast("Scoring failed — try again"); setPhase("asking"); }
  }
  function reset() { setPhase("setup"); setQuestions([]); setResult(null); setLog([]); setQi(0); setAnswer(""); }

  if (phase === "setup") return (
    <div style={{ padding: "14px 18px 30px", position: "relative", zIndex: 2 }} className="jsg-screen">
      <div style={{ ...card, textAlign: "center", marginBottom: 16, background: "linear-gradient(160deg, rgba(124,92,240,0.16), rgba(22,16,51,0.6))" }} className="jsg-reveal">
        <div className="jsg-float" style={{ display: "inline-block" }}><Mic size={34} color={C.amethyst} /></div>
        <h2 style={{ fontFamily: "'Fraunces',serif", fontSize: 22, color: C.text, margin: "6px 0 4px", fontWeight: 600 }}>Live mock interview</h2>
        <p style={{ fontFamily: "'Plus Jakarta Sans'", color: C.mid, fontSize: 13, margin: 0, lineHeight: 1.5 }}>Up to 15 questions tuned to your role and level. Finish with a score and clear next steps.</p>
      </div>
      <div style={card} className="jsg-reveal">
        <Field label="Target role" value={role} onChange={setRole} placeholder="e.g. Azure Data Engineer" />
        <div style={{ ...labelStyle, marginBottom: 8 }}>Difficulty</div>
        <div style={{ display: "flex", gap: 8 }}>{["Easy", "Medium", "Hard"].map((d) => (<button key={d} className="jsg-seg" data-on={diff === d} onClick={() => setDiff(d)}>{d}<span style={{ display: "block", fontSize: 10, opacity: 0.7, marginTop: 2 }}>{counts[d]} Qs</span></button>))}</div>
      </div>
      <div style={{ marginTop: 18 }}><Btn full kind="violet" shimmer onClick={start}><Mic size={16} /> Start interview</Btn></div>
    </div>
  );

  if (phase === "loading" || phase === "scoring") return (
    <div style={{ ...shell.center, position: "relative", zIndex: 2 }}>
      <div className="jsg-float"><Lamp size={56} /></div>
      <div style={{ fontFamily: "'Plus Jakarta Sans'", color: C.text, fontWeight: 700, marginTop: 14 }}>{phase === "loading" ? "Preparing your interviewer…" : "Scoring your interview…"}</div>
    </div>
  );

  if (phase === "asking") {
    const pct = Math.round((qi / questions.length) * 100);
    return (
      <div style={{ padding: "14px 18px 30px", position: "relative", zIndex: 2, display: "flex", flexDirection: "column", minHeight: "100%" }} className="jsg-screen">
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
          <span style={labelStyle}>Question {qi + 1} / {questions.length}</span>
          <span style={{ fontFamily: "'Plus Jakarta Sans'", fontSize: 11, color: C.dim }}>{role} · {diff}</span>
        </div>
        <div className="jsg-track" style={{ marginBottom: 16, marginTop: 0 }}><div className="jsg-fill" style={{ width: pct + "%" }} /></div>
        <div key={qi} style={{ ...card, display: "flex", gap: 12, alignItems: "flex-start", marginBottom: 14, borderColor: C.borderGold }} className="jsg-pop">
          <div style={{ flex: "none", width: 34, height: 34, borderRadius: 11, background: `linear-gradient(135deg,${C.amethyst},${C.amethystDeep})`, display: "flex", alignItems: "center", justifyContent: "center" }}><Sparkles size={18} color="#fff" /></div>
          <div style={{ fontFamily: "'Plus Jakarta Sans'", color: C.text, fontSize: 15.5, lineHeight: 1.5, fontWeight: 600 }}>{questions[qi]}</div>
        </div>
        <textarea className="jsg-area" style={{ minHeight: 150 }} value={answer} onChange={(e) => setAnswer(e.target.value)} placeholder="Type your answer… speak it out loud first, then capture the key points." />
        <div style={{ display: "flex", gap: 10, marginTop: 14 }}>
          <Btn kind="ghost" small onClick={() => submitAnswer(true)}>Skip</Btn>
          <div style={{ flex: 1 }}><Btn full kind="violet" onClick={() => submitAnswer(false)}>{qi + 1 < questions.length ? (<>Next <ArrowRight size={16} /></>) : (<>Finish & score <Check size={16} /></>)}</Btn></div>
        </div>
      </div>
    );
  }

  const r = result || {};
  return (
    <div style={{ padding: "14px 18px 30px", position: "relative", zIndex: 2 }} className="jsg-screen">
      <div style={{ ...card, textAlign: "center", borderColor: C.borderGold, background: "linear-gradient(160deg, rgba(52,211,176,0.10), rgba(22,16,51,0.6))" }} className="jsg-reveal">
        <div style={{ ...labelStyle, color: C.teal, display: "flex", gap: 6, justifyContent: "center", alignItems: "center" }}><Award size={14} /> {r.band || "Result"}</div>
        <div style={{ margin: "8px 0" }}><ScoreRing score={Math.max(0, Math.min(100, r.score || 0))} /></div>
        <p style={{ fontFamily: "'Plus Jakarta Sans'", color: C.mid, fontSize: 13.5, lineHeight: 1.55, margin: "0 auto", maxWidth: 320 }}>{r.summary}</p>
      </div>
      {Array.isArray(r.strengths) && r.strengths.length > 0 && (
        <div style={{ ...card, marginTop: 12 }} className="jsg-reveal" >
          <div style={{ ...labelStyle, color: C.teal, marginBottom: 8, display: "flex", gap: 6, alignItems: "center" }}><Check size={14} /> What worked</div>
          {r.strengths.map((s, i) => (<div key={i} style={{ display: "flex", gap: 8, marginBottom: 6 }}><Check size={15} color={C.teal} style={{ flex: "none", marginTop: 1 }} /><span style={{ fontFamily: "'Plus Jakarta Sans'", color: C.mid, fontSize: 13, lineHeight: 1.45 }}>{s}</span></div>))}
        </div>
      )}
      {Array.isArray(r.improvements) && r.improvements.length > 0 && (
        <div style={{ ...card, marginTop: 12 }} className="jsg-reveal">
          <div style={{ ...labelStyle, color: C.gold, marginBottom: 8, display: "flex", gap: 6, alignItems: "center" }}><Lightbulb size={14} /> Improvement areas</div>
          {r.improvements.map((s, i) => (<div key={i} style={{ display: "flex", gap: 8, marginBottom: 6 }}><ArrowRight size={15} color={C.gold} style={{ flex: "none", marginTop: 1 }} /><span style={{ fontFamily: "'Plus Jakarta Sans'", color: C.mid, fontSize: 13, lineHeight: 1.45 }}>{s}</span></div>))}
        </div>
      )}
      <div style={{ display: "flex", gap: 10, marginTop: 16 }}>
        <Btn full kind="ghost" onClick={reset}><RefreshCw size={15} /> New</Btn>
        <Btn full kind="violet" onClick={() => { setDiff(diff === "Easy" ? "Medium" : "Hard"); reset(); }}>Level up ↑</Btn>
      </div>
    </div>
  );
}

/* ---------------- Tab bar ---------------- */
function TabBar({ tab, setTab }) {
  const tabs = [{ id: "home", label: "Home", Ico: HomeIco }, { id: "toolkit", label: "Toolkit", Ico: Wand2 }, { id: "interview", label: "Interview", Ico: Mic }];
  return (
    <div style={shell.tabbar}>
      {tabs.map((t) => { const on = tab === t.id; const Ico = t.Ico; return (
        <button key={t.id} onClick={() => setTab(t.id)} className="jsg-tab" data-on={on}>
          <Ico size={21} color={on ? C.gold : C.dim} />
          <span>{t.label}</span>
        </button>
      ); })}
    </div>
  );
}

/* ---------------- shells ---------------- */
const shell = {
  bg: { minHeight: "100vh", width: "100%", background: `radial-gradient(120% 80% at 50% -10%, #241657 0%, ${C.ink} 55%, #07050F 100%)`, display: "flex", justifyContent: "center" },
  frame: { position: "relative", width: "100%", maxWidth: 440, minHeight: "100vh", background: "linear-gradient(180deg, #110B28 0%, #0B0720 100%)", display: "flex", flexDirection: "column", overflow: "hidden", boxShadow: "0 0 80px rgba(124,92,240,0.18)" },
  aura: { position: "absolute", top: "-12%", left: "50%", transform: "translateX(-50%)", width: 360, height: 360, background: `radial-gradient(circle, rgba(245,194,75,0.18), transparent 60%)`, filter: "blur(20px)" },
  top: { position: "relative", zIndex: 3, display: "flex", justifyContent: "space-between", alignItems: "center", padding: "16px 18px 10px", borderBottom: `1px solid ${C.border}` },
  scroll: { position: "relative", flex: 1, overflowY: "auto", zIndex: 2 },
  center: { display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", textAlign: "center", padding: 40, minHeight: 360 },
  tabbar: { position: "relative", zIndex: 3, display: "flex", borderTop: `1px solid ${C.border}`, background: "rgba(11,7,32,0.85)", backdropFilter: "blur(10px)", padding: "8px 8px max(8px, env(safe-area-inset-bottom))" },
  toast: { position: "absolute", bottom: 84, left: "50%", transform: "translateX(-50%)", display: "flex", alignItems: "center", gap: 6, background: C.panel, border: `1px solid ${C.borderGold}`, color: C.text, padding: "10px 16px", borderRadius: 14, fontFamily: "'Plus Jakarta Sans'", fontSize: 13, zIndex: 50, boxShadow: "0 8px 30px rgba(0,0,0,0.5)", whiteSpace: "nowrap" },
  sheetWrap: { position: "absolute", inset: 0, zIndex: 60, background: "rgba(6,4,14,0.6)", backdropFilter: "blur(2px)", display: "flex", alignItems: "flex-end" },
  sheet: { width: "100%", background: "linear-gradient(180deg,#181040,#120B30)", borderTop: `1px solid ${C.borderGold}`, borderRadius: "22px 22px 0 0", padding: "14px 16px max(18px, env(safe-area-inset-bottom))" },
};

/* ---------------- global CSS ---------------- */
function GlobalStyle() {
  return (
    <style>{`
      @import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
      * { box-sizing: border-box; -webkit-tap-highlight-color: transparent; }
      ::-webkit-scrollbar { width: 0; height: 0; }
      .jsg-float { animation: jsgFloat 3.4s ease-in-out infinite; }
      @keyframes jsgFloat { 0%,100%{ transform: translateY(0) } 50%{ transform: translateY(-7px) } }
      .jsg-aura { animation: jsgGlow 5s ease-in-out infinite; }
      @keyframes jsgGlow { 0%,100%{ opacity:.7 } 50%{ opacity:1 } }
      .jsg-star { position:absolute; background:#fff; border-radius:50%; opacity:.5; animation: jsgTwinkle ease-in-out infinite; }
      @keyframes jsgTwinkle { 0%,100%{ opacity:.15 } 50%{ opacity:.85 } }
      .jsg-twinkle2 { transform-origin:14px 26px; animation: jsgTw2 2.6s ease-in-out infinite; }
      @keyframes jsgTw2 { 0%,100%{ opacity:.5; transform:scale(.85) } 50%{ opacity:1; transform:scale(1.1) } }
      .jsg-screen { animation: jsgFadeUp .42s ease both; }
      .jsg-reveal { animation: jsgFadeUp .5s ease both; }
      @keyframes jsgFadeUp { from{ opacity:0; transform:translateY(12px) } to{ opacity:1; transform:none } }
      .jsg-pop { animation: jsgPop .26s cubic-bezier(.2,.9,.3,1.2) both; }
      @keyframes jsgPop { from{ opacity:0; transform:scale(.94) } to{ opacity:1; transform:scale(1) } }
      .jsg-slide { animation: jsgSlide .3s cubic-bezier(.2,.8,.2,1) both; }
      @keyframes jsgSlide { from{ transform:translateY(100%) } to{ transform:translateY(0) } }
      .jsg-expand { animation: jsgExpand .28s ease both; overflow:hidden; }
      @keyframes jsgExpand { from{ opacity:0; max-height:0 } to{ opacity:1; max-height:500px } }
      .jsg-row { display:flex; align-items:center; gap:6px; animation: jsgFadeUp .4s ease both; }
      .jsg-spark { position:absolute; font-size:18px; animation: jsgSpark 1.2s ease-out forwards; }
      @keyframes jsgSpark { 0%{ opacity:0; transform:translate(0,0) scale(.4) } 20%{ opacity:1 } 100%{ opacity:0; transform:translate(var(--tx),var(--ty)) scale(1.1) rotate(40deg) } }
      .jsg-input, .jsg-area { width:100%; background:rgba(14,10,31,0.6); border:1px solid ${C.border}; border-radius:12px; color:${C.text}; font-family:'Plus Jakarta Sans',system-ui; font-size:14px; padding:12px 13px; outline:none; transition:border .15s; }
      .jsg-area { resize:vertical; min-height:120px; line-height:1.5; }
      .jsg-input:focus, .jsg-area:focus { border-color:${C.borderGold}; }
      .jsg-input::placeholder, .jsg-area::placeholder { color:${C.dim}; }
      .jsg-btn { border:none; border-radius:14px; font-family:'Plus Jakarta Sans',system-ui; font-weight:700; letter-spacing:.2px; transition:transform .12s, box-shadow .2s; position:relative; overflow:hidden; }
      .jsg-btn:not(:disabled):active { transform: scale(.97); }
      .jsg-shimmer::after { content:''; position:absolute; top:0; left:-60%; width:50%; height:100%; background:linear-gradient(100deg, transparent, rgba(255,255,255,.45), transparent); transform:skewX(-18deg); animation: jsgSweep 2.6s ease-in-out infinite; }
      @keyframes jsgSweep { 0%{ left:-60% } 55%,100%{ left:130% } }
      .jsg-tab { flex:1; background:none; border:none; display:flex; flex-direction:column; align-items:center; gap:3px; padding:6px 0; cursor:pointer; font-family:'Plus Jakarta Sans'; font-size:11px; font-weight:700; color:${C.dim}; transition:color .15s, transform .12s; }
      .jsg-tab[data-on="true"] { color:${C.gold}; transform:translateY(-1px); }
      .jsg-tab:active { transform:scale(.92); }
      .jsg-num { width:30px; height:30px; flex:none; border-radius:10px; display:flex; align-items:center; justify-content:center; font-family:'Fraunces',serif; font-weight:600; color:#241701; background:linear-gradient(135deg,${C.gold},${C.goldDeep}); font-size:15px; }
      .jsg-chip { background:rgba(167,139,250,0.14); border:1px solid ${C.border}; color:${C.amethyst}; font-family:'Plus Jakarta Sans'; font-size:12px; font-weight:700; padding:6px 11px; border-radius:10px; cursor:pointer; display:inline-flex; align-items:center; gap:5px; }
      .jsg-chip:active { transform:scale(.95); }
      .jsg-x { background:none; border:none; color:${C.dim}; cursor:pointer; display:flex; padding:4px; }
      .jsg-x:active { transform:scale(.9); }
      .jsg-mail { display:inline-flex; align-items:center; gap:8px; font-family:'Plus Jakarta Sans'; color:#241701; font-weight:700; font-size:13.5px; text-decoration:none; background:linear-gradient(135deg,${C.gold},${C.goldDeep}); padding:9px 14px; border-radius:12px; }
      .jsg-tile { flex:1; display:flex; flex-direction:column; align-items:center; gap:6px; padding:16px 8px; cursor:pointer; background:rgba(40,28,92,0.4); border:1px solid ${C.border}; border-radius:16px; color:${C.text}; font-family:'Plus Jakarta Sans'; font-size:13px; font-weight:700; transition:transform .12s; }
      .jsg-tile:active { transform:scale(.97); }
      .jsg-add { width:100%; margin-top:8px; display:flex; align-items:center; justify-content:center; gap:6px; padding:11px; border-radius:12px; border:1px dashed ${C.borderGold}; background:rgba(245,194,75,0.07); color:${C.gold}; font-family:'Plus Jakarta Sans'; font-weight:700; font-size:13px; cursor:pointer; }
      .jsg-add:active { transform:scale(.98); }
      .jsg-track { height:8px; background:rgba(167,139,250,0.16); border-radius:99px; margin-top:14px; overflow:hidden; }
      .jsg-fill { height:100%; background:linear-gradient(90deg,${C.gold},${C.goldDeep}); border-radius:99px; transition:width .4s ease; }
      .jsg-check { width:24px; height:24px; flex:none; border-radius:7px; border:2px solid ${C.border}; background:rgba(14,10,31,0.5); color:#241701; cursor:pointer; display:flex; align-items:center; justify-content:center; transition:.15s; }
      .jsg-check[data-on="true"] { background:${C.gold}; border-color:${C.gold}; }
      .jsg-check:disabled { opacity:.4; cursor:default; }
      .jsg-seg { flex:1; padding:11px 6px; border-radius:12px; border:1px solid ${C.border}; background:rgba(14,10,31,0.5); color:${C.mid}; font-family:'Plus Jakarta Sans'; font-weight:700; font-size:13px; cursor:pointer; transition:.15s; }
      .jsg-seg[data-on="true"] { background:linear-gradient(135deg,${C.amethyst},${C.amethystDeep}); color:#fff; border-color:transparent; transform:translateY(-1px); }
      .jsg-export { width:100%; display:flex; align-items:center; justify-content:space-between; padding:13px 14px; margin-bottom:10px; border-radius:14px; border:1px solid ${C.border}; background:rgba(40,28,92,0.45); cursor:pointer; transition:transform .12s, border-color .15s; }
      .jsg-export:active { transform:scale(.98); }
      .jsg-export:hover { border-color:${C.borderGold}; }
      .jsg-export b { display:block; font-family:'Plus Jakarta Sans'; color:${C.text}; font-size:14px; text-align:left; }
      .jsg-export small { display:block; font-family:'Plus Jakarta Sans'; color:${C.dim}; font-size:11.5px; text-align:left; margin-top:1px; }
      .jsg-ei { width:40px; height:40px; border-radius:12px; display:flex; align-items:center; justify-content:center; flex:none; }
      @media (prefers-reduced-motion: reduce) { .jsg-float,.jsg-star,.jsg-aura,.jsg-twinkle2,.jsg-shimmer::after,.jsg-spark { animation:none !important; } }
    `}</style>
  );
}
