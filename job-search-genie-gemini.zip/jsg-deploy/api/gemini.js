/**
 * api/gemini.js  —  Serverless proxy for Gemini 2.5 Flash (free tier)
 *
 * The browser calls  POST /api/gemini  with the SAME JSON body shape the
 * front-end already uses (system + messages).  This function translates
 * that into Gemini's native format, forwards it, and returns a minimal
 * Anthropic-shaped response so the front-end needs zero changes.
 *
 * Vercel: place this file in /api/  — it is auto-deployed as a serverless
 * function at  /api/gemini.
 *
 * Env var required (Vercel dashboard → Settings → Environment Variables):
 *   GEMINI_API_KEY=AIza…
 *
 * Get a free key (no card) at: https://aistudio.google.com/apikey
 * Free tier: 1,500 req/day · 15 RPM · no expiry · no credit card
 */

const MODEL   = "gemini-2.5-flash";
const GEMINI  = `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`;

export default async function handler(req, res) {
  /* ── CORS preflight (handy during local dev) ───────────────────────── */
  res.setHeader("Access-Control-Allow-Origin",  "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  if (req.method === "OPTIONS") return res.status(204).end();
  if (req.method !== "POST")   return res.status(405).json({ error: "Method not allowed" });

  const key = process.env.GEMINI_API_KEY;
  if (!key) return res.status(500).json({ error: "Missing GEMINI_API_KEY env var" });

  try {
    /* ── Parse incoming body ────────────────────────────────────────── */
    const body   = typeof req.body === "string" ? JSON.parse(req.body) : req.body;
    const system = body.system   || "";
    const msgs   = body.messages || [];

    /* ── Build Gemini request ───────────────────────────────────────── */
    // Anthropic format:  [{ role:"user", content:"…" }]
    // Gemini format:     [{ role:"user", parts:[{ text:"…" }] }]
    // Gemini roles:      "user" | "model"  (no "assistant")
    const contents = msgs.map((m) => ({
      role:  m.role === "assistant" ? "model" : "user",
      parts: Array.isArray(m.content)
        // Already a parts array (e.g. document + text for PDF reading)
        ? m.content.map((part) => {
            if (part.type === "text")     return { text: part.text };
            if (part.type === "document") return {
              inlineData: {
                mimeType: part.source.media_type,
                data:     part.source.data,
              },
            };
            return { text: JSON.stringify(part) }; // fallback
          })
        : [{ text: String(m.content) }],
    }));

    const geminiBody = {
      systemInstruction: system ? { parts: [{ text: system }] } : undefined,
      contents,
      generationConfig: {
        maxOutputTokens: body.max_tokens || 1000,
        temperature:     0.7,
      },
    };

    /* ── Call Gemini ────────────────────────────────────────────────── */
    const upstream = await fetch(`${GEMINI}?key=${key}`, {
      method:  "POST",
      headers: { "Content-Type": "application/json" },
      body:    JSON.stringify(geminiBody),
    });

    const data = await upstream.json();

    if (!upstream.ok) {
      console.error("Gemini error:", JSON.stringify(data));
      return res.status(upstream.status).json({ error: data.error?.message || "Gemini error" });
    }

    /* ── Translate response → Anthropic shape ───────────────────────── */
    // The front-end reads: data.content[].text
    const text = data.candidates?.[0]?.content?.parts
      ?.filter((p) => p.text)
      ?.map((p) => p.text)
      ?.join("") ?? "";

    return res.status(200).json({
      content: [{ type: "text", text }],
      model:   MODEL,
      usage:   {
        input_tokens:  data.usageMetadata?.promptTokenCount    ?? 0,
        output_tokens: data.usageMetadata?.candidatesTokenCount ?? 0,
      },
    });
  } catch (err) {
    console.error("Proxy error:", err);
    return res.status(500).json({ error: String(err) });
  }
}
